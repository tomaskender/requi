# REQUI

Requi is a tool used to check for formal and behavioral requirements of submitted school projects.  
  
Formal checks include checking file structure in folders, names of files, the type and compression type of archive and other things that differ from subject to subject and can be a cause for loss of points for submitted projects.
  
Behavioral requirements check for expected return codes and outputs for different sets of provided arguments to the evaluated program.  